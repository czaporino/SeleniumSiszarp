﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Concatenation
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = 5;
            int people = 3;

            Console.WriteLine("The " + people + " people ate " + number + " of sandwiches" );


        }
    }
}
